// Homeschool Hero AI - Prompt Templates
// Replace the {{variables}} with real user/student data before sending to the AI.

const prompts = {
  lessonPlan({ gradeLevel, subject, topic, learningStyle = 'Not specified', lessonLength = '45 minutes' }) {
    return `You are an expert homeschool teacher.

Create a complete homeschool lesson for:

Grade: ${gradeLevel}
Subject: ${subject}
Topic: ${topic}
Student learning style: ${learningStyle}
Lesson length: ${lessonLength}

Include:
1. Lesson title
2. Learning objective
3. Materials needed
4. Warm-up activity
5. Main teaching explanation
6. Guided practice
7. Independent practice
8. Exit ticket
9. Parent teaching tips

Use simple, parent-friendly language. Make it printable and organized.`;
  },

  worksheet({ gradeLevel, subject, topic }) {
    return `Create a printable worksheet for:

Grade: ${gradeLevel}
Subject: ${subject}
Topic: ${topic}

Include:
- Student name line
- Date line
- Clear directions
- 10 practice questions
- Space for answers
- Mix of easy, medium, and challenging questions

Do not include the answer key in this worksheet.`;
  },

  answerKey({ worksheetContent }) {
    return `Create an answer key for this worksheet:

${worksheetContent}

Include:
- Correct answers
- Short explanations for harder questions
- Parent grading notes`;
  },

  quiz({ gradeLevel, subject, topic }) {
    return `Create a short quiz for:

Grade: ${gradeLevel}
Subject: ${subject}
Topic: ${topic}

Include:
- 10 questions
- Multiple choice questions
- Short answer questions
- 1 challenge question
- Point values totaling 100 points

Do not include answers.`;
  },

  weeklyPlan({ gradeLevel, subject, topic }) {
    return `Create a 5-day homeschool weekly plan for:

Grade: ${gradeLevel}
Subject: ${subject}
Topic: ${topic}

For Monday through Friday include:
- Daily objective
- Warm-up
- Lesson activity
- Practice work
- Exit ticket
- Homework or review

Friday should include a quiz or project.`;
  },

  progressReport({ studentName, gradeLevel, completedLessons, quizScores, parentNotes = 'None' }) {
    return `Create a parent-friendly progress report for:

Student name: ${studentName}
Grade: ${gradeLevel}
Completed lessons: ${completedLessons}
Quiz scores: ${quizScores}
Parent notes: ${parentNotes}

Include:
- Strengths
- Areas to improve
- Suggested next steps
- Encouraging summary`;
  },

  teachItToMe({ gradeLevel, topic }) {
    return `Explain this topic to a child in grade ${gradeLevel}:

Topic: ${topic}

Use:
- Simple words
- Examples
- A short story or real-life example
- 3 check-for-understanding questions`;
  },

  pdfFormat({ content }) {
    return `Format this homeschool content into a clean printable layout:

${content}

Use:
- Clear section headings
- Numbered questions
- Student name line
- Date line
- Parent notes section
- Page-friendly spacing`;
  }
};

export default prompts;
