// Example Node/Next.js API route for generating a lesson.
// Install: npm install openai
// Add OPENAI_API_KEY to your environment variables.

import OpenAI from 'openai';
import prompts from '../ai/prompts.js';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

export async function generateLesson({ gradeLevel, subject, topic, learningStyle, lessonLength }) {
  const prompt = prompts.lessonPlan({
    gradeLevel,
    subject,
    topic,
    learningStyle,
    lessonLength
  });

  const response = await openai.responses.create({
    model: 'gpt-4.1-mini',
    input: prompt
  });

  return response.output_text;
}

// Test example:
// generateLesson({
//   gradeLevel: '5th Grade',
//   subject: 'Math',
//   topic: 'Improper Fractions to Mixed Numbers',
//   learningStyle: 'Visual learner',
//   lessonLength: '45 minutes'
// }).then(console.log);
