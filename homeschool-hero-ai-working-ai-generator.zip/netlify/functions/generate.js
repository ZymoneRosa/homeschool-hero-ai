exports.handler = async function(event) {
  if (event.httpMethod !== 'POST') {
    return json(405, { error: 'Method not allowed' });
  }

  if (!process.env.OPENAI_API_KEY) {
    return json(500, { error: 'Missing OPENAI_API_KEY. Add it in your hosting environment variables.' });
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const prompt = buildPrompt(body);

    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        input: prompt,
        temperature: 0.7,
        max_output_tokens: 3000
      })
    });

    const data = await response.json();
    if (!response.ok) {
      return json(response.status, { error: data.error?.message || 'OpenAI request failed.' });
    }

    const content = data.output_text || extractText(data) || 'No lesson text was returned.';
    return json(200, { content });
  } catch (error) {
    return json(500, { error: error.message || 'Server error.' });
  }
};

function buildPrompt({ grade, subject, topic, learningStyle, contentType }) {
  const type = contentType || 'complete';
  const base = `You are Homeschool Hero AI, a warm expert homeschool teacher. Create parent-friendly homeschool educational material.\n\nGrade: ${grade || '5th Grade'}\nSubject: ${subject || 'Math'}\nTopic: ${topic || 'Fractions'}\nLearning style: ${learningStyle || 'Not sure'}\n\nUse clear headings, printable formatting, age-appropriate language, and original questions. Do not mention that you are an AI.`;

  if (type === 'worksheet') {
    return `${base}\n\nCreate a printable worksheet only. Include student name line, date line, clear directions, 12 practice questions, space for answers, and a separate answer key at the bottom.`;
  }
  if (type === 'quiz') {
    return `${base}\n\nCreate a quiz only. Include 10 questions with point values totaling 100 points, a mix of multiple choice and short answer, one challenge question, and a separate answer key.`;
  }
  if (type === 'lesson') {
    return `${base}\n\nCreate a full lesson only. Include lesson title, learning objective, materials, warm-up, mini lesson, guided practice, independent practice, exit ticket, and parent teaching tips.`;
  }
  return `${base}\n\nCreate a complete lesson pack with these sections:\n1. Lesson title\n2. Learning objective\n3. Materials needed\n4. Warm-up\n5. Mini lesson explained simply\n6. Guided practice\n7. Printable worksheet with 10 questions and answer spaces\n8. Short quiz with point values totaling 100 points\n9. Answer key for worksheet and quiz\n10. Parent teaching tips\n11. Suggested next lesson.`;
}

function extractText(data) {
  try {
    return data.output
      ?.flatMap(item => item.content || [])
      ?.map(part => part.text || '')
      ?.join('\n')
      ?.trim();
  } catch {
    return '';
  }
}

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  };
}
