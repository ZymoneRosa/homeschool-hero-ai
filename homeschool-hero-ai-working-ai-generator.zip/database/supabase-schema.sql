-- Homeschool Hero AI - Supabase Starter Database

create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  full_name text,
  plan text default 'free',
  created_at timestamp with time zone default now()
);

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.users(id) on delete cascade,
  first_name text not null,
  grade_level text not null,
  learning_style text,
  created_at timestamp with time zone default now()
);

create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.users(id) on delete cascade,
  student_id uuid references public.students(id) on delete set null,
  subject text not null,
  topic text not null,
  grade_level text not null,
  lesson_title text,
  lesson_content text not null,
  created_at timestamp with time zone default now()
);

create table if not exists public.worksheets (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid references public.lessons(id) on delete cascade,
  worksheet_content text not null,
  answer_key text,
  created_at timestamp with time zone default now()
);

create table if not exists public.quizzes (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid references public.lessons(id) on delete cascade,
  quiz_content text not null,
  answer_key text,
  score integer,
  created_at timestamp with time zone default now()
);

create table if not exists public.progress (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references public.students(id) on delete cascade,
  lesson_id uuid references public.lessons(id) on delete cascade,
  status text default 'not_started',
  score integer,
  completed_at timestamp with time zone
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.users(id) on delete cascade,
  stripe_customer_id text,
  stripe_subscription_id text,
  plan_name text default 'free',
  status text default 'inactive',
  renews_at timestamp with time zone,
  created_at timestamp with time zone default now()
);
